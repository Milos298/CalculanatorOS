"""CalculanatorOS shell commands."""
import random
import time
import os
import config
import calculator
import devices
import storage

HELP = "HELP | HELP_BOOK | APPS | APP <name> | HARDWARE | INFO | VER | VERSION | DATE | UPTIME | LED ON | LED OFF | WIFI | WIFI STATUS | WIFI IP | WIFI SCAN | WIFI CONNECT | WIFI DISCONNECT | SCAN | CONNECT | DISCONNECT | NETINFO | IP | BT STATUS | BT INFO | BT SCAN | BLUETOOTH | BLUETOOTH INFO | BT | PKG HELP | PKG LIST | PKG INSTALL | NOTE | READ.NOTES | CALC | INSTRUMENTS | INSTRUMENT_PANEL | MATRIX | REBOOT | PING | EXIT | QUIT"
LED_STATE = False

def app_calculator():
    run("CALC")

def app_notes():
    run("NOTE")

def app_instruments():
    instrument_panel()

def app_settings():
    print("Name:", config.NAME, "| Version:", config.VERSION, "| Build:", config.BUILD)

# Register another app by adding a name/description/callback pair here.
APP_REGISTRY = {
    "calculator": ("Run the safe arithmetic calculator.", app_calculator),
    "notes": ("Create a note in Pico flash storage.", app_notes),
    "instruments": ("Open the board hardware panel.", app_instruments),
    "settings": ("Show the firmware configuration.", app_settings),
}

def apps_menu():
    names = list(APP_REGISTRY)
    while True:
        print("=== CALCULANATOROS APPS ===")
        for index, name in enumerate(names, 1):
            print(str(index) + ".", name.title(), "—", APP_REGISTRY[name][0])
        print("0. Back")
        choice = input("Apps> ").strip().lower()
        if choice == "0":
            return
        if choice.isdigit() and 1 <= int(choice) <= len(names):
            APP_REGISTRY[names[int(choice) - 1]][1]()
        elif choice in APP_REGISTRY:
            APP_REGISTRY[choice][1]()
        else:
            print("Choose an app number, name, or 0.")

def instrument_panel():
    global LED_STATE
    while True:
        print("=== INSTRUMENT PANEL ===")
        print("1 RP2350 chip temperature | 2 Uptime | 3 Wi-Fi | 4 LED | 5 BLE scan | 0 Back")
        choice = input("Instrument> ").strip()
        if choice == "1":
            temperature, error = devices.chip_temperature_celsius()
            if error:
                print(error)
            else:
                print("RP2350 chip temperature:", round(temperature, 1), "°C (approximate; not room temperature)")
        elif choice == "2":
            try:
                print("Running for", time.ticks_ms() // 1000, "seconds." )
            except Exception:
                print("The timer is unavailable.")
        elif choice == "3":
            print(devices.wifi_status())
        elif choice == "4":
            current, error = devices.led_state()
            if error:
                print(error)
            else:
                LED_STATE = not current
                print(devices.led_set(LED_STATE)[1])
        elif choice == "5":
            found, error = devices.bluetooth_scan()
            if error:
                print("Bluetooth scan failed:", error)
            elif not found:
                print("No BLE devices found.")
            else:
                for address, details in found.items():
                    print("-", details[0], address, "RSSI", details[1], "dBm")
        elif choice == "0":
            return
        else:
            print("Choose 0, 1, 2, 3, 4, or 5.")

def package_command(arg):
    parts = arg.strip().split(" ", 1)
    action = parts[0].upper() if parts else "HELP"
    package = parts[1].strip() if len(parts) > 1 else ""
    if action == "HELP":
        print("PKG LIST | PKG INSTALL <micropython-lib-package>")
        print("Installation requires Wi-Fi. A package runs third-party Python code.")
    elif action == "LIST":
        try:
            names = [name for name in os.listdir() if name.endswith((".py", ".mpy"))]
            print("Python files:", ", ".join(names) if names else "none")
        except Exception as error:
            print("Could not list files:", error)
    elif action == "INSTALL":
        if not package or any(char not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-" for char in package):
            print("Usage: PKG INSTALL package_name")
            return
        if input("Install package '" + package + "'? Type INSTALL to confirm: ").strip() != "INSTALL":
            print("Installation cancelled.")
            return
        try:
            import mip
            mip.install(package)
            print("Installation complete:", package)
        except Exception as error:
            print("Installation failed:", error)
    else:
        print("Unknown action. Use PKG HELP.")

def run(command):
    parts = command.strip().split(" ", 1)
    name = parts[0].upper() if parts else ""
    arg = parts[1].strip() if len(parts) > 1 else ""
    if not name:
        return True
    if name in ("EXIT", "QUIT"):
        print("The shell is closing. The Pico will remain powered on.")
        return False
    if name == "HELP":
        print("Commands:", HELP)
    elif name == "HELP_BOOK":
        print("=== CALCULANATOROS HELP BOOK ===")
        print("01 | HELP — shows the short command list.")
        print("02 | HELP_BOOK — shows this detailed help book.")
        print("03 | INFO — shows information about the system and MicroPython.")
        print("04 | APPS — shows the built-in app launcher list.")
        print("05 | APP <name> — launches calculator, notes, instruments, or settings.")
        print("06 | VER — shows the version and build.")
        print("07 | VERSION — alias for VER.")
        print("08 | DATE — shows the Pico clock; it may not be set.")
        print("09 | UPTIME — shows how long the board has been running.")
        print("10 | LED ON — turns on the Pico's onboard LED.")
        print("11 | LED OFF — turns off the Pico's onboard LED.")
        print("12 | WIFI — shows the connection status and IP address.")
        print("13 | WIFI STATUS — alias for WIFI.")
        print("14 | WIFI IP — alias for WIFI.")
        print("15 | WIFI SCAN — scans for Wi-Fi networks and their signal strength.")
        print("16 | SCAN — alias for WIFI SCAN.")
        print("17 | WIFI CONNECT [SSID] — connects to a network; the password is not saved.")
        print("18 | CONNECT [SSID] — alias for WIFI CONNECT.")
        print("19 | WIFI DISCONNECT — disconnects the Pico from Wi-Fi.")
        print("20 | DISCONNECT — alias for WIFI DISCONNECT.")
        print("21 | NETINFO — shows the Pico's Wi-Fi status and IP address.")
        print("22 | IP — alias for NETINFO.")
        print("23 | BT STATUS — shows Bluetooth LE status.")
        print("24 | BT INFO — alias for BT STATUS.")
        print("25 | BLUETOOTH — alias for BT STATUS.")
        print("26 | BLUETOOTH INFO — alias for BT STATUS.")
        print("27 | BT — alias for BT STATUS.")
        print("28 | BT SCAN — scans for BLE devices for 5 seconds; it does not pair with them.")
        print("29 | PKG HELP — shows package installer help.")
        print("30 | PKG LIST — lists Python files stored on the Pico.")
        print("31 | PKG INSTALL <name> — installs a package through mip after confirmation.")
        print("32 | NOTE — saves a note to internal flash storage.")
        print("33 | READ.NOTES — reads notes from internal flash storage.")
        print("34 | CALC [expression] — calculates +, -, *, / and parentheses; e.g. CALC 2*(3+4).")
        print("35 | INSTRUMENTS — opens the hardware panel; temperature is the approximate RP2350 chip temperature.")
        print("36 | INSTRUMENT_PANEL — alias for INSTRUMENTS.")
        print("37 | MATRIX — displays a text effect.")
        print("38 | REBOOT — restarts the board.")
        print("39 | PING — ICMP ping is not implemented in this firmware.")
        print("40 | EXIT — closes the shell; the board remains powered on.")
        print("41 | QUIT — alias for EXIT.")
        print("42 | NOTE — PKG INSTALL requires Wi-Fi and runs third-party code; install trusted packages only.")
    elif name == "INFO":
        print(config.NAME, "is an experimental firmware shell for the Pico 2 W.")
        print("It runs on MicroPython; it is not desktop Linux or Windows.")
    elif name == "HARDWARE":
        print("Mode: PICO HARDWARE. The LED, Wi-Fi, Bluetooth LE, and RP2350 chip-temperature sensor use board hardware.")
        print("The internal temperature reading is approximate chip temperature, not room temperature.")
    elif name == "APPS":
        apps_menu()
    elif name == "APP":
        app = arg.lower()
        if app in APP_REGISTRY:
            APP_REGISTRY[app][1]()
        else:
            print("Usage: APP <" + "|".join(APP_REGISTRY) + ">")
    elif name in ("VER", "VERSION"):
        print(config.NAME, config.VERSION, "build", config.BUILD)
    elif name == "DATE":
        print(time.localtime())
    elif name == "UPTIME":
        try:
            print("Running for", time.ticks_ms() // 1000, "seconds." )
        except Exception:
            print("The timer is unavailable.")
    elif name == "LED":
        state = arg.lower()
        if state not in ("on", "off"):
            print("Usage: LED ON or LED OFF")
        else:
            print(devices.led_set(state == "on")[1])
    elif name == "WIFI" and arg.upper().split(" ", 1)[0] in ("SCAN", "CONNECT", "DISCONNECT", "STATUS", "IP"):
        wifi_parts = arg.split(" ", 1)
        action = wifi_parts[0].upper()
        wifi_name = wifi_parts[1].strip() if len(wifi_parts) > 1 else ""
        if action == "SCAN":
            rows, error = devices.wifi_scan()
            if error:
                print("Scan failed:", error)
            else:
                for row in rows:
                    try:
                        ssid = row[0].decode()
                    except Exception:
                        ssid = str(row[0])
                    print("-", ssid, "RSSI", row[3], "dBm")
        elif action == "CONNECT":
            ssid = wifi_name or input("Wi-Fi name (SSID): ").strip()
            password = input("Password (will not be saved): ")
            print(devices.wifi_connect(ssid, password)[1])
        elif action == "DISCONNECT":
            _, wlan = devices.wifi_interface()
            if wlan:
                wlan.disconnect()
                print("Wi-Fi disconnected.")
            else:
                print("Wi-Fi is unavailable.")
        else:
            print(devices.wifi_status())
    elif name in ("WIFI", "NETINFO", "IP"):
        print(devices.wifi_status())
    elif name == "SCAN":
        rows, error = devices.wifi_scan()
        if error:
            print("Scan failed:", error)
        else:
            print("Found Wi-Fi networks:")
            for row in rows:
                try:
                    ssid = row[0].decode()
                except Exception:
                    ssid = str(row[0])
                print("-", ssid, "RSSI", row[3], "dBm")
    elif name in ("BT", "BLUETOOTH"):
        action = arg.upper() or "STATUS"
        if action in ("STATUS", "INFO"):
            print(devices.bluetooth_status())
        elif action == "SCAN":
            print("Scanning for Bluetooth LE devices for 5 seconds...")
            found, error = devices.bluetooth_scan()
            if error:
                print("Bluetooth scan failed:", error)
            elif not found:
                print("No BLE devices found.")
            else:
                for address, details in found.items():
                    print("-", details[0], address, "RSSI", details[1], "dBm")
        else:
            print("Usage: BT STATUS or BT SCAN (Bluetooth Low Energy)")
    elif name == "PKG":
        package_command(arg)
    elif name == "CONNECT":
        ssid = arg or input("Wi-Fi name (SSID): ").strip()
        password = input("Password (will not be saved): ")
        print(devices.wifi_connect(ssid, password)[1])
    elif name == "DISCONNECT":
        _, wlan = devices.wifi_interface()
        if wlan:
            wlan.disconnect()
            print("Wi-Fi disconnected.")
        else:
            print("Wi-Fi is unavailable.")
    elif name == "NOTE":
        note = arg or input("Note: ")
        storage.add_note(note)
        print("Note saved to", config.NOTES_FILE)
    elif name == "READ.NOTES":
        notes = storage.read_notes()
        print(notes if notes else "There are no notes yet.")
    elif name == "CALC":
        expression = arg or input("Example 2*(3+4): ")
        try:
            print("=", calculator.calculate(expression))
        except Exception as error:
            print("Expression error:", error)
    elif name in ("INSTRUMENTS", "INSTRUMENT_PANEL"):
        instrument_panel()
    elif name == "MATRIX":
        alphabet = "01ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        for _ in range(10):
            print("".join(random.choice(alphabet) for _ in range(32)))
            if hasattr(time, "sleep_ms"):
                time.sleep_ms(80)
            else:
                time.sleep(0.08)
    elif name == "REBOOT":
        try:
            import machine
            print("Restarting...")
            machine.reset()
        except Exception:
            print("Restart is only available on a Pico.")
    elif name == "PING":
        print("ICMP ping is not implemented in this MicroPython shell.")
    else:
        print("Unknown command. Type HELP.")
    return True
