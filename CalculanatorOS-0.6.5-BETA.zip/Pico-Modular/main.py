"""MicroPython automatically runs main.py when the board starts."""
import config
import commands
import account

def main():
    print("\n+================================================+")
    print("|                 CALCULANATOROS                |")
    print("|              PICO 2 W MODULAR                 |")
    print("+================================================+")
    print(config.VERSION, "| BUILD", config.BUILD)
    if not account.register_or_login():
        print("The terminal did not start.")
        return
    print("Type HELP to list commands.")
    while True:
        try:
            command = input("calc> ")
            if not commands.run(command):
                break
        except KeyboardInterrupt:
            print("\nInterrupted. Type HELP or EXIT.")
        except Exception as error:
            print("Command error:", error)

main()
