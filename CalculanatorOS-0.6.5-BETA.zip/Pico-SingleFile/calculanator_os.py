"""CalculanatorOS 0.4.0 — standalone MicroPython version for the Pico 2 W.
Upload this file as main.py to a board running MicroPython.
"""
import random
import time
import os
import hashlib

NAME = "CalculanatorOS"
VERSION = "0.5.0"
NOTES = "notes.txt"
LED_STATE = [False]

def calculate(text):
    text = text.replace(" ", "")
    pos = [0]
    def peek():
        return text[pos[0]] if pos[0] < len(text) else ""
    def take():
        char = peek()
        if not char:
            raise ValueError("Expression is incomplete.")
        pos[0] += 1
        return char
    def factor():
        if peek() == "+":
            take()
            return factor()
        if peek() == "-":
            take()
            return -factor()
        if peek() == "(":
            take()
            value = expression()
            if take() != ")":
                raise ValueError("Missing closing parenthesis.")
            return value
        start = pos[0]
        dot = False
        while peek().isdigit() or (peek() == "." and not dot):
            if peek() == ".":
                dot = True
            take()
        if start == pos[0]:
            raise ValueError("Expected a number.")
        return float(text[start:pos[0]])
    def term():
        value = factor()
        while peek() in ("*", "/"):
            op = take()
            right = factor()
            if op == "/":
                if right == 0:
                    raise ValueError("Division by zero is not allowed.")
                value /= right
            else:
                value *= right
        return value
    def expression():
        value = term()
        while peek() in ("+", "-"):
            op = take()
            right = term()
            value = value + right if op == "+" else value - right
        return value
    result = expression()
    if pos[0] != len(text):
        raise ValueError("Unexpected character: " + text[pos[0]])
    return result

def get_wifi():
    try:
        import network
        mode = getattr(network, "STA_IF", None)
        if mode is None:
            mode = network.WLAN.IF_STA
        return network.WLAN(mode)
    except Exception:
        return None

def chip_temperature_celsius():
    """Read approximate RP2350 chip temperature, not room temperature."""
    try:
        from machine import ADC
        voltage = ADC(4).read_u16() * (3.3 / 65535)
        return 27 - (voltage - 0.706) / 0.001721, None
    except Exception as error:
        return None, str(error)

def password_prompt(label):
    try:
        import getpass
        return getpass.getpass(label)
    except Exception:
        # Some MicroPython USB REPLs echo the typed password.
        return input(label)

def hash_password(password, salt):
    value = (salt + password).encode()
    for _ in range(1024):
        value = hashlib.sha256(value).digest()
    return "".join("%02x" % byte for byte in value)

def make_salt():
    try:
        raw = os.urandom(16)
        return "".join("%02x" % byte for byte in raw)
    except Exception:
        return "%08x%08x%08x%08x" % tuple(random.getrandbits(32) for _ in range(4))

def open_calculator_app():
    run("CALC")

def open_notes_app():
    run("NOTE")

def open_instruments_app():
    run("INSTRUMENTS")

# Add another app by adding a name/description/callback entry here.
APP_REGISTRY = {
    "calculator": ("Run the arithmetic calculator.", open_calculator_app),
    "notes": ("Create and read notes.", open_notes_app),
    "instruments": ("Open the Pico hardware panel.", open_instruments_app),
}

def apps_menu():
    names = list(APP_REGISTRY)
    while True:
        print("=== CALCULANATOROS APPS ===")
        for index, name in enumerate(names, 1):
            print(str(index) + ".", name.title(), "—", APP_REGISTRY[name][0])
        print("0. Back")
        choice = input("Apps> ").strip().lower()
        if choice == "0":
            return
        if choice.isdigit() and 1 <= int(choice) <= len(names):
            APP_REGISTRY[names[int(choice) - 1]][1]()
        elif choice in APP_REGISTRY:
            APP_REGISTRY[choice][1]()
        else:
            print("Choose an app number, name, or 0.")

def register_or_login():
    account_file = "calculanator_user.txt"
    try:
        with open(account_file, "r") as file:
            parts = file.read().strip().split("|", 2)
        if len(parts) != 3:
            raise ValueError("Invalid account file format.")
        saved_user, salt, digest = parts
    except OSError:
        saved_user = salt = digest = None
    except ValueError as error:
        print("Account file is invalid:", error)
        return False

    if saved_user is None:
        print("FIRST START — REGISTRATION")
        while True:
            username = input("Username: ").strip()
            allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-"
            if not username or any(char not in allowed for char in username):
                print("Username may contain letters, numbers, periods, hyphens, and underscores.")
                continue
            password = password_prompt("Password: ")
            confirmation = password_prompt("Confirm password: ")
            if len(password) < 4:
                print("Password must have at least 4 characters.")
                continue
            if password != confirmation:
                print("Passwords do not match. Try again.")
                continue
            salt = make_salt()
            digest = hash_password(password, salt)
            with open(account_file, "w") as file:
                file.write(username + "|" + salt + "|" + digest)
            print("Registration complete. Welcome,", username + "!")
            return True

    print("SIGN IN")
    for _ in range(3):
        username = input("Username: ").strip()
        password = password_prompt("Password: ")
        if username == saved_user and hash_password(password, salt) == digest:
            print("Sign-in successful. Welcome,", username + "!")
            return True
        print("Incorrect username or password.")
    print("Too many failed attempts.")
    return False

def bluetooth_status():
    try:
        import bluetooth
        return "Bluetooth LE is " + ("on." if bluetooth.BLE().active() else "off.")
    except Exception as error:
        return "Bluetooth LE is unavailable: " + str(error)

def bluetooth_scan(duration_ms=5000):
    try:
        import bluetooth
        ble = bluetooth.BLE()
        found = {}
        scan_result = getattr(bluetooth, "_IRQ_SCAN_RESULT", 5)
        def decode_name(payload):
            index = 0
            while index < len(payload):
                size = payload[index]
                if size == 0 or index + size >= len(payload):
                    break
                if payload[index + 1] in (0x08, 0x09):
                    try:
                        return payload[index + 2:index + size + 1].decode()
                    except Exception:
                        return "(name unavailable)"
                index += size + 1
            return "(unnamed)"
        def on_event(event, data):
            if event == scan_result:
                _, address, _, rssi, payload = data
                address_text = ":".join("%02X" % byte for byte in bytes(address))
                found[address_text] = (decode_name(bytes(payload)), rssi)
        ble.active(True)
        ble.irq(on_event)
        ble.gap_scan(duration_ms, active=True)
        started = time.ticks_ms()
        while time.ticks_diff(time.ticks_ms(), started) < duration_ms + 500:
            time.sleep_ms(50)
        ble.gap_scan(None)
        ble.irq(None)
        return found, None
    except Exception as error:
        return None, str(error)

def package_command(arg):
    parts = arg.strip().split(" ", 1)
    action = parts[0].upper() if parts else "HELP"
    package = parts[1].strip() if len(parts) > 1 else ""
    if action == "HELP":
        print("PKG LIST | PKG INSTALL <package-name>")
        print("Installation requires Wi-Fi and confirmation, and downloads third-party Python code.")
    elif action == "LIST":
        try:
            names = [name for name in os.listdir() if name.endswith((".py", ".mpy"))]
            print("Python files:", ", ".join(names) if names else "none")
        except Exception as error:
            print("Could not list files:", error)
    elif action == "INSTALL":
        if not package or any(char not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-" for char in package):
            print("Usage: PKG INSTALL package_name")
            return
        if input("Install package '" + package + "'? Type INSTALL to confirm: ").strip() != "INSTALL":
            print("Installation cancelled.")
            return
        try:
            import mip
            mip.install(package)
            print("Installation complete:", package)
        except Exception as error:
            print("Installation failed:", error)
    else:
        print("Unknown action. Use PKG HELP.")

def run(command):
    parts = command.strip().split(" ", 1)
    name = parts[0].upper() if parts else ""
    arg = parts[1].strip() if len(parts) > 1 else ""
    if not name:
        return True
    if name in ("EXIT", "QUIT"):
        print("The shell is closing. The Pico will remain powered on.")
        return False
    if name == "HELP":
        print("HELP | HELP_BOOK | APPS | APP <name> | HARDWARE | INFO | VER | VERSION | DATE | UPTIME | LED ON | LED OFF | WIFI | WIFI STATUS | WIFI IP | WIFI SCAN | WIFI CONNECT | WIFI DISCONNECT | SCAN | CONNECT | DISCONNECT | NETINFO | IP | BT STATUS | BT INFO | BT SCAN | BLUETOOTH | BLUETOOTH INFO | BT | PKG HELP | PKG LIST | PKG INSTALL | NOTE | READ.NOTES | CALC | INSTRUMENTS | INSTRUMENT_PANEL | MATRIX | REBOOT | PING | EXIT | QUIT")
    elif name == "HELP_BOOK":
        print("=== CALCULANATOROS HELP BOOK ===")
        print("01 | HELP — shows the short command list.")
        print("02 | HELP_BOOK — shows this detailed help book.")
        print("03 | INFO — shows information about the system and MicroPython.")
        print("04 | APPS — lists the built-in apps.")
        print("05 | APP <name> — launches a built-in app by name.")
        print("06 | HARDWARE — reports Pico hardware mode.")
        print("07 | VER — shows the version and build.")
        print("08 | VERSION — alias for VER.")
        print("09 | DATE — shows the Pico clock; it may not be set.")
        print("10 | UPTIME — shows how long the board has been running.")
        print("11 | LED ON — turns on the Pico's onboard LED.")
        print("12 | LED OFF — turns off the Pico's onboard LED.")
        print("13 | WIFI — shows the connection status and IP address.")
        print("14 | WIFI STATUS — alias for WIFI.")
        print("15 | WIFI IP — alias for WIFI.")
        print("16 | WIFI SCAN — scans for Wi-Fi networks and their signal strength.")
        print("17 | SCAN — alias for WIFI SCAN.")
        print("18 | WIFI CONNECT [SSID] — connects to a network; the password is not saved.")
        print("19 | CONNECT [SSID] — alias for WIFI CONNECT.")
        print("20 | WIFI DISCONNECT — disconnects the Pico from Wi-Fi.")
        print("21 | DISCONNECT — alias for WIFI DISCONNECT.")
        print("22 | NETINFO — shows the Pico's Wi-Fi status and IP address.")
        print("23 | IP — alias for NETINFO.")
        print("24 | BT STATUS — shows Bluetooth LE status.")
        print("25 | BT INFO — alias for BT STATUS.")
        print("26 | BLUETOOTH — alias for BT STATUS.")
        print("27 | BLUETOOTH INFO — alias for BT STATUS.")
        print("28 | BT — alias for BT STATUS.")
        print("29 | BT SCAN — scans for BLE devices for 5 seconds; it does not pair with them.")
        print("30 | PKG HELP — shows package installer help.")
        print("31 | PKG LIST — lists Python files stored on the Pico.")
        print("32 | PKG INSTALL <name> — installs a package through mip after confirmation.")
        print("33 | NOTE — saves a note to internal flash storage.")
        print("34 | READ.NOTES — reads notes from internal flash storage.")
        print("35 | CALC [expression] — calculates +, -, *, / and parentheses; e.g. CALC 2*(3+4).")
        print("36 | INSTRUMENTS — opens the hardware panel; temperature is approximate RP2350 chip temperature.")
        print("37 | INSTRUMENT_PANEL — alias for INSTRUMENTS.")
        print("38 | MATRIX — displays a text effect.")
        print("39 | REBOOT — restarts the board.")
        print("40 | PING — ICMP ping is not implemented in this firmware.")
        print("41 | EXIT — closes the shell; the board remains powered on.")
        print("42 | QUIT — alias for EXIT.")
        print("43 | NOTE — PKG INSTALL requires Wi-Fi and runs third-party code; install trusted packages only.")
    elif name == "INFO":
        print(NAME, "is a firmware shell for the Pico 2 W. It runs on MicroPython.")
    elif name == "HARDWARE":
        print("Mode: PICO HARDWARE. LED, Wi-Fi, Bluetooth LE, and the RP2350 chip-temperature sensor use board hardware.")
        print("The internal temperature reading is approximate chip temperature, not room temperature.")
    elif name == "APPS":
        apps_menu()
    elif name == "APP":
        app = arg.lower()
        if app in APP_REGISTRY:
            APP_REGISTRY[app][1]()
        else:
            print("Usage: APP <" + "|".join(APP_REGISTRY) + ">")
    elif name in ("VER", "VERSION"):
        print(NAME, VERSION)
    elif name == "DATE":
        print(time.localtime())
    elif name == "UPTIME":
        try:
            print(time.ticks_ms() // 1000, "seconds")
        except Exception:
            print("The timer is unavailable.")
    elif name == "LED":
        if arg.lower() not in ("on", "off"):
            print("Usage: LED ON or LED OFF")
        else:
            try:
                from machine import Pin
                Pin("LED", Pin.OUT).value(1 if arg.lower() == "on" else 0)
                print("LED updated.")
            except Exception as error:
                print("LED is unavailable:", error)
    elif name == "WIFI" and arg.upper().split(" ", 1)[0] in ("SCAN", "CONNECT", "DISCONNECT", "STATUS", "IP"):
        wifi_parts = arg.split(" ", 1)
        action = wifi_parts[0].upper()
        wifi_name = wifi_parts[1].strip() if len(wifi_parts) > 1 else ""
        wlan = get_wifi()
        if action == "SCAN":
            if wlan is None:
                print("Wi-Fi library is unavailable.")
            else:
                try:
                    wlan.active(True)
                    for row in wlan.scan():
                        try:
                            ssid = row[0].decode()
                        except Exception:
                            ssid = str(row[0])
                        print("-", ssid, "RSSI", row[3], "dBm")
                except Exception as error:
                    print("Scan failed:", error)
        elif action == "CONNECT":
            ssid = wifi_name or input("Wi-Fi name (SSID): ").strip()
            password = input("Password (will not be saved): ")
            if wlan is None:
                print("Wi-Fi is unavailable.")
            else:
                try:
                    wlan.active(True)
                    wlan.connect(ssid, password)
                    for _ in range(20):
                        if wlan.isconnected():
                            print("Connected. IP:", wlan.ifconfig()[0])
                            break
                        time.sleep(1)
                    else:
                        print("Connection failed.")
                except Exception as error:
                    print("Wi-Fi error:", error)
        elif action == "DISCONNECT":
            if wlan:
                wlan.disconnect()
                print("Wi-Fi disconnected.")
            else:
                print("Wi-Fi is unavailable.")
        elif wlan and wlan.isconnected():
            print("Connected. IP:", wlan.ifconfig()[0])
        else:
            print("Wi-Fi is not connected.")
    elif name in ("WIFI", "NETINFO", "IP"):
        wlan = get_wifi()
        if wlan is None:
            print("Wi-Fi library is unavailable.")
        elif wlan.isconnected():
            print("Connected. IP:", wlan.ifconfig()[0])
        else:
            print("Wi-Fi is not connected.")
    elif name == "SCAN":
        wlan = get_wifi()
        if wlan is None:
            print("Wi-Fi library is unavailable.")
        else:
            try:
                wlan.active(True)
                for row in wlan.scan():
                    try:
                        ssid = row[0].decode()
                    except Exception:
                        ssid = str(row[0])
                    print("-", ssid, "RSSI", row[3], "dBm")
            except Exception as error:
                print("Scan failed:", error)
    elif name == "CONNECT":
        ssid = arg or input("Wi-Fi name (SSID): ").strip()
        password = input("Password (will not be saved): ")
        wlan = get_wifi()
        if wlan is None:
            print("Wi-Fi is unavailable.")
        else:
            try:
                wlan.active(True)
                wlan.connect(ssid, password)
                for _ in range(20):
                    if wlan.isconnected():
                        print("Connected. IP:", wlan.ifconfig()[0])
                        break
                    time.sleep(1)
                else:
                    print("Connection failed.")
            except Exception as error:
                print("Wi-Fi error:", error)
    elif name == "DISCONNECT":
        wlan = get_wifi()
        if wlan:
            wlan.disconnect()
            print("Wi-Fi disconnected.")
        else:
            print("Wi-Fi is unavailable.")
    elif name in ("BT", "BLUETOOTH"):
        action = arg.upper() or "STATUS"
        if action in ("STATUS", "INFO"):
            print(bluetooth_status())
        elif action == "SCAN":
            print("Scanning for Bluetooth LE devices for 5 seconds...")
            found, error = bluetooth_scan()
            if error:
                print("Bluetooth scan failed:", error)
            elif not found:
                print("No BLE devices found.")
            else:
                for address, details in found.items():
                    print("-", details[0], address, "RSSI", details[1], "dBm")
        else:
            print("Usage: BT STATUS or BT SCAN (Bluetooth Low Energy)")
    elif name == "PKG":
        package_command(arg)
    elif name == "NOTE":
        note = arg or input("Note: ")
        with open(NOTES, "a") as file:
            file.write(note + "\n")
        print("Note saved.")
    elif name == "READ.NOTES":
        try:
            with open(NOTES, "r") as file:
                print(file.read())
        except OSError:
            print("There are no notes yet.")
    elif name == "CALC":
        try:
            print("=", calculate(arg or input("Example 2*(3+4): ")))
        except Exception as error:
            print("Expression error:", error)
    elif name in ("INSTRUMENTS", "INSTRUMENT_PANEL"):
        while True:
            print("=== INSTRUMENT PANEL ===")
            print("1 RP2350 chip temperature | 2 Uptime | 3 Wi-Fi | 4 LED | 0 Back")
            choice = input("Instrument> ").strip()
            if choice == "1":
                temperature, error = chip_temperature_celsius()
                if error:
                    print("Chip temperature sensor is unavailable:", error)
                else:
                    print("RP2350 chip temperature:", round(temperature, 1), "°C (approximate; not room temperature)")
            elif choice == "2":
                print(time.ticks_ms() // 1000, "seconds")
            elif choice == "3":
                _, wlan = wifi()
                if wlan and wlan.isconnected():
                    print("Connected. IP:", wlan.ifconfig()[0])
                else:
                    print("Wi-Fi is not connected.")
            elif choice == "4":
                LED_STATE[0] = not LED_STATE[0]
                try:
                    from machine import Pin
                    Pin("LED", Pin.OUT).value(1 if LED_STATE[0] else 0)
                    print("LED is", "on." if LED_STATE[0] else "off.")
                except Exception as error:
                    print("LED is unavailable:", error)
            elif choice == "0":
                break
            else:
                print("Choose 0, 1, 2, 3, or 4.")
    elif name == "MATRIX":
        for _ in range(10):
            print("".join(random.choice("01ABCDEFGHIJKLMNOPQRSTUVWXYZ") for _ in range(32)))
            time.sleep(0.08)
    elif name == "REBOOT":
        try:
            import machine
            machine.reset()
        except Exception as error:
            print("Restart is unavailable:", error)
    elif name == "PING":
        print("ICMP ping is not implemented.")
    else:
        print("Unknown command. Type HELP.")
    return True

def main():
    print("\n" + "=" * 32)
    print("+==============================================+")
    print("|                 CALCULANATOROS              |")
    print("|                PICO 2 W EDITION             |")
    print("+==============================================+")
    print(NAME, VERSION)
    print("Mode: PICO HARDWARE")
    print("=" * 32)
    if not register_or_login():
        print("The terminal did not start.")
        return
    print("Type HELP to list commands.")
    while True:
        try:
            if not run(input("calc> ")):
                break
        except KeyboardInterrupt:
            print("\nInterrupted. Type HELP or EXIT.")
        except Exception as error:
            print("Command error:", error)

if __name__ == "__main__":
    main()
