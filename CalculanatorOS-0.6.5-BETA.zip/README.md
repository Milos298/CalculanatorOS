# CalculanatorOS

CalculanatorOS is an experimental project with a desktop edition and a lightweight MicroPython edition for the Raspberry Pi Pico 2 W. It is a learning project, not a standalone desktop operating-system kernel.

## Desktop edition

Requirements: Windows, macOS, or Linux with Python 3.

Run from a terminal:

```text
py desktop/CalculanatorOS.py
```

On systems where `py` is unavailable, use `python3 desktop/CalculanatorOS.py`.

The desktop build includes a command shell, calculator, notes, settings, instrument simulator, file sandbox, and Python source editor. Hardware readings are simulated on PC. Type `HELP` after signing in. The app's local login does not protect the computer or its files.

## Raspberry Pi Pico 2 W

The Pico edition runs on MicroPython; it does not run desktop Linux or Windows.

1. Download the official [MicroPython UF2 for Pico 2 W](https://micropython.org/download/RPI_PICO2_W/).
2. Connect the board over USB while holding BOOTSEL, then copy the UF2 to the drive that appears.
3. Open the board in Thonny or another MicroPython editor.
4. For the modular edition, copy every `.py` file in `Pico-Modular` to the board's root. Keep `main.py` beside the other modules.
5. Restart the Pico and use its USB serial console.

For the single-file edition, upload `Pico-SingleFile/calculanator_os.py` as `main.py` instead.

The Pico firmware controls the onboard LED and Wi-Fi/Bluetooth features. Its temperature reading is an estimate from the RP2350 chip sensor, not room temperature. Pico account information is stored on the device's flash; this shell is not a security boundary.

## Updating the PC edition

Use `UPDATE CHECK` to check for a newer desktop version. Use `UPDATE` to check and install after confirmation. The updater verifies the manifest, SHA-256 checksum, and Python syntax, creates a backup, then asks you to restart.

The updater reads `release-assets/calculanatoros-update.json` and `release-assets/CalculanatorOS.py` from this repository's `main` branch. To publish a desktop update, update both files and set the manifest's version, build, file size, and SHA-256 hash to match the script. Pico firmware updates are separate.

## Downloads

- [Download the complete CalculanatorOS package (ZIP)](https://raw.githubusercontent.com/Milos298/CalculanatorOS/main/release-assets/CalculanatorOS-0.6.5-BETA.zip)
- Or use GitHub's **Code → Download ZIP** to download the source tree.
